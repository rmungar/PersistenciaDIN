# This file contains the path to the root directory of the project.
import os

basedir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))